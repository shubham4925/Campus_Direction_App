package com.example.campusdirection;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Spinner sourceSpinner, destinationSpinner;
    Button btnShowRoute;

    String[] locationNames = {
            "Canteen",
            "Garden",
            "ATU College",
            "Main Gate",
            "Library",
            "Parking"
    };

    String[] locationCoords = {
            "16.877916,74.259911",  // Canteen
            "16.876914,74.261690",  // Garden
            "16.874304,74.261698",  // ATU College
            "16.871825,74.262943",  // Main Gate
            "16.877247,74.261147",  // Library
            "16.875731,74.262957"   // Parking
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sourceSpinner = findViewById(R.id.sourceSpinner);
        destinationSpinner = findViewById(R.id.destinationSpinner);
        btnShowRoute = findViewById(R.id.btnShowRoute);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, locationNames);

        sourceSpinner.setAdapter(adapter);
        destinationSpinner.setAdapter(adapter);

        btnShowRoute.setOnClickListener(v -> showRoute());
    }

    private void showRoute() {
        int sourceIndex = sourceSpinner.getSelectedItemPosition();
        int destinationIndex = destinationSpinner.getSelectedItemPosition();

        String source = locationCoords[sourceIndex];
        String destination = locationCoords[destinationIndex];

        String uri = "https://www.google.com/maps/dir/?api=1&origin="
                + source + "&destination=" + destination;

        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
        intent.setPackage("com.google.android.apps.maps");

        startActivity(intent);
    }
    }
